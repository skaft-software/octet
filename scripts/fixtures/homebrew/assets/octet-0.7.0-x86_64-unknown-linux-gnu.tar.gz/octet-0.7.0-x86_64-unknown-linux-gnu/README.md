octet fixture release
